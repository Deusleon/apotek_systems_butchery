<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Traits\HasRoles;


class UserController extends Controller
{
    use HasRoles;


    public function index()
    {
        $users = User::orderBy('name')->get();


        return view('users.index', compact("users"));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:50',
            'position' => 'nullable|string|max:50',
            'role' => 'required',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
            'store_id' => 'required'
        ]);

        $user = new User;
        $user->name = $request->name;
        $user->position = $request->position;
        $user->email = $request->email;
        $user->mobile = $request->mobile;
        $user->status = '-1';
        $user->password = Hash::make($request->password);
        $user->store_id = $request->store_id;
        $user->save();

        $user->syncRoles($request->role);

        session()->flash("alert-success", "User created successfully!");
        return back();
    }

    public function update(Request $request)
    {
        $request->validate([
            'name1' => 'required|string|max:100',
            'role1' => 'required',
            'position1' => 'nullable|string|max:50',
            'store_id' => 'required',
        ]);


        $user = User::findOrFail($request->UserID);
        $user->name = $request->name1;
        $user->position = $request->position1;
        $user->mobile = $request->mobile1;
        $user->store_id = $request->store_id;
        $user->save();

        $user->syncRoles($request->role1);

        session()->flash("alert-success", "User updated successfully!");
        return back();
    }


    public function deActivate(Request $request)
    {

        if ($request->status == 1) {
            $user = new User;
            $user = User::findOrFail($request->userid);
            $user->status = 0;
            $user->save();

            session()->flash("alert-success", "User de-activated successfully!");
            return redirect()->back();
        }
        if ($request->status == 0 || $request->status == -1) {
            $user = new User;
            $user = User::findOrFail($request->userid);
            $user->status = 1;
            $user->save();

            session()->flash("alert-success", "User activated successfully!");
            return redirect()->back();
        }

    }

    public function getRoleID(Request $request)
    {
        $data = DB::table('roles')
            ->select('id')
            ->where('name', $request->role)
            ->get();

        return $data[0]->id;
    }

    public function passwordReset($email)
    {
        $token = csrf_token();
        return view('auth.passwords.admin_reset', compact('token', 'email'));
    }

    public function passwordResetUpdate(Request $request)
    {
        $user = User::where('email', $request->email)->first();
        $user->password = Hash::make($request->password);
        $user->save();

        session()->flash("alert-success", "User password reset successfully!");
        return redirect()->route('users.index');
    }


    /**
     * Log the user out of the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function logout(Request $request)
    {
        if(auth()->user()->checkPermission('Manage All Stores'))
        {
            DB::beginTransaction();

            $update_store = DB::table('users')
                ->where('id', Auth::user()->id)
                ->update(
                    [
                        'store_id'=>0
                    ]
                );

            DB::commit();

        }

        $this->guard()->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect()->route('login');
    }


    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        return \Illuminate\Support\Facades\Auth::guard();
    }

}
