<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StockOrderLevelController extends Controller
{
    //
}
