<?php

namespace App\Http\Controllers;

use App\CurrentStock;
use App\Product;
use App\Requisition;
use App\RequisitionDetail;
use App\Setting;
use App\StockTracking;
use App\Store;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use PDF;
use Yajra\DataTables\DataTables;

class RequisitionController extends Controller
{
    public function index()
    {
//        if (Auth()->user()->cannot('View Requisitions')) {
//            abort(403, 'Access Denied');
//        }

        return view('requisitions.index');
    }

    public function getRequisitions(Request $request)
    {
//        if (Auth()->user()->cannot('View Requisitions')) {
//            abort(403, 'Access Denied');
//        }

        if ($request->ajax()) {
            $data = Requisition::with(['reqDetails'])
                ->leftJoin(DB::raw('inv_stores as from_store'), 'requisitions.from_store', '=', 'from_store.id')
                ->leftJoin(DB::raw('inv_stores as to_store'), 'requisitions.to_store', '=', 'to_store.id')
                ->selectRaw('requisitions.*, to_store.name as toStore, from_store.name as fromStore')
                ->orderBy('requisitions.id', 'DESC');
            return DataTables::of($data)
                ->addColumn('action', function ($row) {
                    $btn_view = '';
                    if (Auth()->user()->can('Manage Product Categories')) {
                        if (Auth()->user()->can('Manage Product Categories')) {
                            $btn_view = '<a href="' . route('requisitions.view', $row->id) . '" class="btn btn-warning btn-sm" title="VIEW">View</a>';
                        }
                    }

                    return $btn_view;
                })
                ->addColumn('products', function ($row) {
                    $prod = '<span class="badge badge-primary p-1">' . $row->reqDetails->count() . ' Products</span>';
                    return $prod;
                })
                ->addColumn('reqDate', function ($row) {
                    return $row->created_at;
                })
                ->rawColumns(['action', 'products', 'reqTo', 'reqDate'])
                ->make(true);
        }
    }

    public function create()
    {
//        if (Auth()->user()->cannot('Create Requisitions')) {
//            abort(403, 'Access Denied');
//        }

        $items = Product::where('status', 1)->get();
        $users = User::where('status', 1)->get();
        $stores = Store::get();
        return view('requisitions.create', compact('items', 'users', 'stores'));
    }

    function search_items(Request $request)
    {
//        if (Auth()->user()->cannot('Create Requisitions')) {
//            abort(403, 'Access Denied');
//        }

        $request->validate([
            'item_id' => 'required'
        ]);

        $item = Product::find($request->item_id);

        if (!$item) {
            return response()->json(['message' => 'Item not found'], 404);
        }

        return response()->json([
            'item' => $item,
        ]);
    }

    public function store(Request $request)
    {
//        if (Auth()->user()->cannot('Create Requisitions')) {
//            abort(403, 'Access Denied');
//        }

        $orders = json_decode($request->orders);

        $last_req_id = Requisition::orderBy('id', 'DESC')->first();

        if ($last_req_id) {
            $Id = ++$last_req_id->id;
        } else {
            $Id = 1;
        }

        $req_no = date('m') . date('d') . str_pad($Id, 5, '0', STR_PAD_LEFT);

        if (!empty($orders)) {
            $requisition = new Requisition();
            $requisition->req_no = $req_no;
            $requisition->notes = $request->notes;
            $requisition->from_store = $request->from_store;
            $requisition->to_store = $request->to_store;
            $requisition->status = 0;
            $requisition->created_by = Auth::user()->id;

            $success = false;
            DB::beginTransaction();

            $success = $requisition->save();

            foreach ($orders as $order_details) {
                $order_detail = new RequisitionDetail();
                $order_detail->req_id = $requisition->id;
                $order_detail->product = $order_details->itemss->id;
                $order_detail->quantity = $order_details->quantity;
                $order_detail->unit = $order_details->unit;
                $success = $order_detail->save();
            }
            session()->flash("alert-success", "Requisition Created Successfully!");
            DB::commit();

            return back();
        }
    }

    public function show($id)
    {
//        if (Auth()->user()->cannot('View Requisitions Details')) {
//            abort(403, 'Access Denied');
//        }

        $items = Product::where('status', 1)->get();
        $stores = Store::get();

        $requisition = Requisition::with(['reqDetails', 'creator'])->find($id);

        $fromStore = Store::findOrFail($requisition->from_store);
        $toStore = Store::findOrFail($requisition->to_store);

        $requisitionDet = RequisitionDetail::with('products_')
            ->leftJoin('inv_current_stock', 'inv_current_stock.product_id', 'requisition_details.product')
            ->selectRaw('requisition_details.*, sum(inv_current_stock.quantity) as qty_oh')
            ->groupBy('inv_current_stock.product_id')
            // ->havingRaw(DB::raw('sum(inv_current_stock.quantity) > 0'))
            // ->where('inv_current_stock.store_id', $requisition->to_store)
            ->where('requisition_details.req_id', $id)
            ->get();

        // $data = json_encode($requisitionDet);
        // dd($data);

        return view("requisitions.show", compact('requisition', 'requisitionDet', 'fromStore', 'toStore', 'items', 'stores'));
    }

    public function printReq(Request $request)
    {
//        if (Auth()->user()->cannot('Print Requisitions')) {
//            abort(403, 'Access Denied');
//        }

        $req_id = $request->req_id;

        $requisition = Requisition::with(['reqDetails', 'reqTo', 'creator'])->find($req_id);

        $requisitionDet = RequisitionDetail::with('products_')->where('req_id', $req_id)->get();
        $pharmacy = $this->companyInfo();

        $view = 'requisitions.pdf.print_requisitions';
        $output = 'request.pdf';
        $pdf = PDF::loadView($view, compact('requisition', 'requisitionDet', 'pharmacy'));
        return $pdf->stream($output);
    }

    private function companyInfo()
    {
        $pharmacy['name'] = Setting::where('id', 100)->value('value');
        $pharmacy['address'] = Setting::where('id', 106)->value('value');
        $pharmacy['phone'] = Setting::where('id', 107)->value('value');
        $pharmacy['email'] = Setting::where('id', 108)->value('value');
        $pharmacy['website'] = Setting::where('id', 109)->value('value');

        return $pharmacy;
    }

    public function update(Request $request)
    {
//        if (Auth()->user()->cannot('Approve Requisitions')) {
//            abort(403, 'Access Denied');
//        }

        $req_id = $request->requisition_id;
        $remarks = $request->remarks;
        $from_store = $request->from_store;
        $to_store = $request->to_store;

        $orders = json_decode($request->orders);
        // dd($orders);
        if (!empty($orders)) {
            $requisition = Requisition::findOrFail($req_id);
            $requisition->from_store = $request->from_store;
            $requisition->to_store = $request->to_store;
            $requisition->updated_by = Auth::user()->id;

            $success = false;
            DB::beginTransaction();

            $success = $requisition->save();

            RequisitionDetail::query()
                ->where('req_id', $req_id)
                ->whereNull('quantity_given')
                ->delete();

            foreach ($orders as $order_details) {
                $check_req = RequisitionDetail::query()
                    ->where('req_id', $req_id)
                    ->where('product', $order_details->products_->id)
                    ->get();

                if (!$check_req->isEmpty()) {
                    $updateDetails = [
                        'quantity' => $order_details->quantity,
                        'unit' => $order_details->unit
                    ];

                    RequisitionDetail::query()
                        ->where('req_id', $req_id)
                        ->where('product', $order_details->products_->id)
                        ->update($updateDetails);
                } else {
                    $order_detail = new RequisitionDetail();
                    $order_detail->req_id = $requisition->id;
                    $order_detail->product = $order_details->products_->id;
                    $order_detail->quantity = $order_details->quantity;
                    $order_detail->unit = $order_details->unit;
                    $order_detail->save();
                }


            }
            session()->flash("alert-success", "Requisition Created Successfully!");
            DB::commit();

            return back();
        }


        session()->flash("alert-success", "Requisition Accepted Successfully!");
        return back();
        // $content = array_map(null, $request->product_id, $request->qty);

        // foreach ($content as $value) {
        //     $product_id = $value[0];
        //     $qty_given = $value[1];

        //     RequisitionDetail::where('req_id', $req_id)
        //         ->where('product', $product_id)
        //         ->update(array('quantity_given' => $qty_given));
        // }

        // $req = Requisition::findOrFail($req_id);
        // $req->remarks = $remarks;
        // $req->updated_by = Auth::user()->id;
        // $req->status = 1;
        // $req->save();
    }

    public function destroy(Request $request)
    {
//        if (Auth()->user()->cannot('Delete Requisitions')) {
//            abort(403, 'Access Denied');
//        }

        Requisition::destroy($request->req_id);
        DB::table('requisition_details')->where('req_id', $request->req_id)->delete();

        return redirect()->route('requisitions.index');
        session()->flash("alert-success", "Requisition Deleted Successfully!");
    }

    public function issueReq()
    {
//        if (Auth()->user()->cannot('View Requisitions')) {
//            abort(403, 'Access Denied');
//        }

        return view('issue_requisitions.index');
    }

    public function getRequisitionsIssue(Request $request)
    {
//        if (Auth()->user()->cannot('View Requisitions Issue')) {
//            abort(403, 'Access Denied');
//        }

        if ($request->ajax()) {
            $data = Requisition::with(['reqDetails'])
                ->leftJoin(DB::raw('inv_stores as from_store'), 'requisitions.from_store', '=', 'from_store.id')
                ->leftJoin(DB::raw('inv_stores as to_store'), 'requisitions.to_store', '=', 'to_store.id')
                ->selectRaw('requisitions.*, to_store.name as toStore, from_store.name as fromStore')
                ->orderBy('requisitions.id', 'DESC');
            return DataTables::of($data)
                ->addColumn('action', function ($row) {
                    $btn_view = '';
                    if (Auth()->user()->can('Manage Product Categories')) {
                        if (Auth()->user()->can('Manage Product Categories')) {
                            $btn_view = '<a href="' . route('requisitions.issue', $row->id) . '" class="btn btn-warning btn-sm" title="ISSUE">Issue</a>';
                        }
                    }

                    return $btn_view;
                })
                ->addColumn('products', function ($row) {
                    $prod = '<span class="badge badge-primary p-1">' . $row->reqDetails->count() . ' Products</span>';
                    return $prod;
                })
                ->addColumn('reqDate', function ($row) {
                    return $row->created_at;
                })
                ->rawColumns(['action', 'products', 'reqTo', 'reqDate'])
                ->make(true);
        }
    }

    public function issue($id)
    {
//        if (Auth()->user()->cannot('View Requisitions Issue')) {
//            abort(403, 'Access Denied');
//        }

        $items = Product::where('status', 1)->get();
        $stores = Store::get();

        $requisition = Requisition::with(['reqDetails', 'creator'])->find($id);

        $fromStore = Store::findOrFail($requisition->from_store);
        $toStore = Store::findOrFail($requisition->to_store);

        $requisitionDet = RequisitionDetail::with('products_')
            ->leftJoin('inv_current_stock', 'inv_current_stock.product_id', 'requisition_details.product')
            ->selectRaw('requisition_details.*, sum(inv_current_stock.quantity) as qty_oh')
            ->groupBy('inv_current_stock.product_id')
            // ->havingRaw(DB::raw('sum(inv_current_stock.quantity) > 0'))
            // ->where('inv_current_stock.store_id', $fromStore)
            ->where('requisition_details.req_id', $id)
            ->get();

        return view("issue_requisitions.show", compact('requisition', 'requisitionDet', 'fromStore', 'toStore', 'items', 'stores'));
    }

    public function issuing(Request $request)
    {
//        if (Auth()->user()->cannot('View Requisitions Issue')) {
//            abort(403, 'Access Denied');
//        }

        $req_id = $request->requisition_id;
        $remarks = $request->remarks;
        $store_id = $request->store_id;

        $content = array_map(null, $request->product_id, $request->qty, $request->qty_req);
        // dd($content);

        foreach ($content as $value) {

            $product_id = $value[0];
            $qty_given = $value[1];
            $qty_req = $value[2];

            $current_stock = CurrentStock::where('product_id', $product_id)
                ->where('quantity', '=', 0)
                ->get();

            $previous_current_stock = CurrentStock::select('id')
                ->where('product_id', $product_id)
                ->orderby('id', 'desc')
                ->first();

            if (!($current_stock->isEmpty())) {
                //update
//                dd('kulwa');
                $get_current_stock = CurrentStock::find($current_stock->first()->id);

                $check_buy_price = number_format($get_current_stock->unit_cost, 2);


                $update_stock = CurrentStock::find($current_stock->first()->id);
                $update_stock->batch_number = null;

                //TODO: Commented not understood
//                if ($request->expire_date == "YES") {
//                    if ($single_item['expire_date'] != null) {
//                        $update_stock->expiry_date = date('Y-m-d', strtotime($single_item['expire_date']));
//                    } else {
//                        $update_stock->expiry_date = null;
//                    }
//                } else {
//                    $update_stock->expiry_date = null;
//                }

                $update_stock->quantity = $qty_given;
                $update_stock->store_id = $store_id;
                $update_stock->save();
                $overal_stock_id = $update_stock->id;
            } else {

                $stock = new CurrentStock;
                $stock->product_id = $product_id;
                $stock->batch_number = null;

//                if ($request->expire_date == "YES") {
//
//                    if ($single_item['expire_date'] != null) {
//                        $stock->expiry_date = date('Y-m-d', strtotime($single_item['expire_date']));
//                    } else {
//                        $stock->expiry_date = null;
//                    }
//                } else {
//                    $stock->expiry_date = null;
//                }

                $stock->expiry_date = null;
                $stock->quantity = $qty_given;
                $stock->unit_cost = null;
                $stock->store_id = $store_id;

                $stock->save();
                $overal_stock_id = $stock->id;
            }

            $stock_tracking = new StockTracking();
            $stock_tracking->stock_id = $overal_stock_id;
            $stock_tracking->product_id = $product_id;
            $stock_tracking->quantity = $qty_given;
            $stock_tracking->store_id = $store_id;
            $stock_tracking->updated_by = Auth::user()->id;
            $stock_tracking->out_mode = 'Requisition Issued';
            $stock_tracking->updated_at = date('Y-m-d');
            $stock_tracking->movement = 'IN';
            $stock_tracking->save();

            $remain_qty = $qty_req - $qty_given;

            RequisitionDetail::where('req_id', $req_id)
                ->where('product', $product_id)
                ->update(array('quantity_given' => $qty_given));
        }

        $req = Requisition::findOrFail($req_id);
        $req->remarks = $remarks;
        $req->updated_by = Auth::user()->id;
        $req->status = 1;
        $req->save();


        session()->flash("alert-success", "Requisition Accepted Successfully!");
        return back();
    }
}
